'use client';
import { useSearchParams } from 'next/navigation';

export default function ResultsPage() {
    const params = useSearchParams();
    const score = Number(params.get('score'));
    const total = Number(params.get('total'));
    const percentage = total > 0 ? ((score / total) * 100).toFixed(1) : 0;

    return (
        <div className="min-h-screen p-6 bg-gray-50 text-neutral-900">
            <div className="max-w-xl mx-auto bg-white shadow-md p-6 rounded-lg text-center">
                <h1 className="text-3xl font-bold mb-4">Test Completed</h1>
                <p className="text-xl mb-2">You got <strong>{score}</strong> out of <strong>{total}</strong> correct.</p>
                <p className="text-lg text-blue-600">Score: {percentage}%</p>

                <div className="mt-6 flex justify-center gap-4">
                    <a href="/" className="px-4 py-2 bg-neutral-900 text-white rounded hover:bg-neutral-800 transition">
                        Return Home
                    </a>
                    <button
                        onClick={() => window.history.back()}
                        className="px-4 py-2 border border-neutral-400 text-neutral-700 rounded hover:bg-neutral-100 transition"
                    >
                        Review
                    </button>
                </div>
            </div>
        </div>
    );
}