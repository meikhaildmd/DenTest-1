// src/app/adat/page.tsx
import Link from 'next/link';

interface Section {
  id: number;
  name: string;
}

export default async function AdatHome() {
  let sections: Section[] = [];

  try {
    const res = await fetch('http://127.0.0.1:8000/api/sections/adat/', {
      cache: 'no-store',
    });

    if (!res.ok) throw new Error('Failed to fetch');

    sections = await res.json();
  } catch (err) {
    return (
      <div className="p-6 text-red-600">
        <h1 className="text-xl font-bold">Failed to load ADAT sections</h1>
        <p>{(err as Error).message}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 bg-gray-50 text-neutral-900">
      <h1 className="text-3xl font-bold mb-6">ADAT Sections</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {sections.map(section => (
          <Link
            key={section.id}
            href={`/adat/section/${section.id}`}
            className="block bg-white shadow rounded p-4 hover:bg-neutral-100 transition-colors"
          >
            {section.name}
          </Link>
        ))}
      </div>
    </div>
  );
}