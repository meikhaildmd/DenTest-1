import Link from 'next/link';

interface Subject {
  id: number;
  name: string;
}

interface SectionWithSubjects {
  id: number;
  name: string;
  subjects: Subject[];
}

interface SubjectProgress {
  subject_id: number;
  correct: number;
  total: number;
}

export default async function SectionPage({ params }: { params: { sectionId: string } }) {
  const { sectionId } = params;

  let section: SectionWithSubjects | null = null;
  let progressMap: Record<number, SubjectProgress> = {};

  try {
    const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

    // Fetch section and subjects
    const res = await fetch(`${baseUrl}/api/sections/${sectionId}/with-subjects/`, {
      cache: "no-store",
    });
    if (!res.ok) throw new Error('Failed to fetch section');
    section = await res.json();

    // Fetch user progress (if logged in)
    const progRes = await fetch(`${baseUrl}/api/user-progress/`, {
      credentials: 'include',
      cache: 'no-store',
    });
    if (progRes.ok) {
      const progress: SubjectProgress[] = await progRes.json();
      progressMap = Object.fromEntries(progress.map(p => [p.subject_id, p]));
    }
  } catch (err) {
    return (
      <div className="p-6 text-red-600">
        <h1 className="text-xl font-bold">Failed to load subjects</h1>
        <p>{(err as Error).message}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 bg-gray-50 text-neutral-900">
      <h1 className="text-3xl font-bold mb-6">{section!.name} Subjects</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {section!.subjects.map(subject => {
          const prog = progressMap[subject.id];
          const percent = prog ? Math.round((prog.correct / prog.total) * 100) : null;

          return (
            <Link
              key={subject.id}
              href={`/adat/quiz/${subject.id}`}
              className="block bg-white shadow rounded p-4 hover:bg-neutral-100 transition-colors"
            >
              <div className="font-semibold">{subject.name}</div>
              {percent !== null && (
                <div className="text-sm text-gray-600 mt-1">{percent}% correct</div>
              )}
            </Link>
          );
        })}
      </div>
    </div>
  );
}