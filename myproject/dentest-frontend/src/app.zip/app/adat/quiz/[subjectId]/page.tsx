import { use } from 'react';
import QuizEngine from '@/components/QuizEngine';

export default function Page({ params }: { params: Promise<{ subjectId: string }> }) {
  const { subjectId } = use(params);
  return <QuizEngine subjectId={subjectId} />;
}