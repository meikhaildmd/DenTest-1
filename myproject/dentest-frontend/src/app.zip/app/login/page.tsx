'use client';
import { useState } from 'react';

export default function LoginPage() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = async () => {
        try {
            // 1. Get CSRF token from Django (sets csrftoken cookie)
            await fetch("http://127.0.0.1:8000/api/csrf/", {
                credentials: 'include',
            });

            // 2. Read CSRF token from cookie
            const csrfToken = getCookie("csrftoken");

            if (!csrfToken) throw new Error("CSRF token missing");

            // 3. Send login request with CSRF token in header
            const res = await fetch("http://127.0.0.1:8000/api/login/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRFToken": csrfToken,
                },
                credentials: "include",
                body: JSON.stringify({ username, password }),
            });

            if (!res.ok) {
                throw new Error("Login failed");
            }

            alert("Logged in!");
        } catch (err: any) {
            console.error(err);
            alert("Login error: " + err.message);
        }
    };

    // Helper to get cookie value by name
    function getCookie(name: string) {
        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? decodeURIComponent(match[2]) : null;
    }

    return (
        <div className="p-8">
            <h1 className="text-2xl font-bold mb-4">Login</h1>
            <input
                type="text"
                placeholder="Username"
                className="block border p-2 mb-2 w-64 bg-neutral-800 text-white placeholder-gray-400"
                value={username}
                onChange={e => setUsername(e.target.value)}
            />

            <input
                type="password"
                placeholder="Password"
                className="block border p-2 mb-2 w-64 bg-neutral-800 text-white placeholder-gray-400"
                value={password}
                onChange={e => setPassword(e.target.value)}
            />
            />
            <button onClick={handleLogin} className="bg-blue-600 text-white px-4 py-2 rounded">
                Login
            </button>
        </div>
    );
}